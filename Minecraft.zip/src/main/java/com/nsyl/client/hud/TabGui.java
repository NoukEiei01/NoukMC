/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.hud;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import com.nsyl.client.Category;
import com.nsyl.client.Feature;
import com.nsyl.client.NsylClient;
import com.nsyl.client.clickgui.ClickGui;
import com.nsyl.client.events.KeyPressListener;
import com.nsyl.client.hacks.TooManyHaxHack;
import com.nsyl.client.other_features.TabGuiOtf;
import com.nsyl.client.util.ChatUtils;
import com.nsyl.client.util.RenderUtils;

public final class TabGui implements KeyPressListener
{
	private static final NsylClient CLIENT = NsylClient.INSTANCE;
	private static final Minecraft MC = NsylClient.MC;
	
	private final ArrayList<Tab> tabs = new ArrayList<>();
	private final TabGuiOtf tabGuiOtf =
		NsylClient.INSTANCE.getOtfs().tabGuiOtf;
	
	private int width;
	private int height;
	private int selected;
	private boolean tabOpened;
	
	public TabGui()
	{
		NsylClient.INSTANCE.getEventManager().add(KeyPressListener.class, this);
		
		LinkedHashMap<Category, Tab> tabMap = new LinkedHashMap<>();
		for(Category category : Category.values())
			tabMap.put(category, new Tab(category.getName()));
		
		ArrayList<Feature> features = new ArrayList<>();
		features.addAll(NsylClient.INSTANCE.getHax().getAllHax());
		features.addAll(NsylClient.INSTANCE.getCmds().getAllCmds());
		features.addAll(NsylClient.INSTANCE.getOtfs().getAllOtfs());
		
		for(Feature feature : features)
			if(feature.getCategory() != null)
				tabMap.get(feature.getCategory()).add(feature);
			
		tabs.addAll(tabMap.values());
		tabs.forEach(Tab::updateSize);
		updateSize();
	}
	
	private void updateSize()
	{
		width = 64;
		for(Tab tab : tabs)
		{
			int tabWidth = MC.font.width(tab.name) + 10;
			if(tabWidth > width)
				width = tabWidth;
		}
		height = tabs.size() * 10;
	}
	
	@Override
	public void onKeyPress(KeyPressEvent event)
	{
		if(event.getAction() != GLFW.GLFW_PRESS)
			return;
		
		if(tabGuiOtf.isHidden())
			return;
		
		if(tabOpened)
			switch(event.getKeyCode())
			{
				case GLFW.GLFW_KEY_LEFT:
				tabOpened = false;
				break;
				
				default:
				tabs.get(selected).onKeyPress(event.getKeyCode());
				break;
			}
		else
			switch(event.getKeyCode())
			{
				case GLFW.GLFW_KEY_DOWN:
				if(selected < tabs.size() - 1)
					selected++;
				else
					selected = 0;
				break;
				
				case GLFW.GLFW_KEY_UP:
				if(selected > 0)
					selected--;
				else
					selected = tabs.size() - 1;
				break;
				
				case GLFW.GLFW_KEY_RIGHT:
				tabOpened = true;
				break;
			}
	}
	
	public void render(GuiGraphics context, float partialTicks)
	{
		if(tabGuiOtf.isHidden())
			return;
		
		PoseStack matrixStack = context.pose();
		matrixStack.pushPose();
		matrixStack.translate(2, 23, 100);
		
		drawBox(context, 0, 0, width, height);
		context.enableScissor(0, 0, width, height);
		
		int textY = 1;
		int txtColor = NsylClient.INSTANCE.getGui().getTxtColor();
		Font tr = MC.font;
		for(int i = 0; i < tabs.size(); i++)
		{
			String tabName = tabs.get(i).name;
			if(i == selected)
				tabName = (tabOpened ? "<" : ">") + tabName;
			
			context.drawString(tr, tabName, 2, textY, txtColor, false);
			textY += 10;
		}
		
		context.disableScissor();
		
		if(tabOpened)
		{
			Tab tab = tabs.get(selected);
			
			matrixStack.pushPose();
			matrixStack.translate(width + 2, 0, 0);
			
			drawBox(context, 0, 0, tab.width, tab.height);
			context.enableScissor(0, 0, tab.width, tab.height);
			
			int tabTextY = 1;
			for(int i = 0; i < tab.features.size(); i++)
			{
				Feature feature = tab.features.get(i);
				String fName = feature.getName();
				
				if(feature.isEnabled())
					fName = "\u00a7a" + fName + "\u00a7r";
				
				if(i == tab.selected)
					fName = ">" + fName;
				
				context.drawString(tr, fName, 2, tabTextY, txtColor, false);
				tabTextY += 10;
			}
			
			context.disableScissor();
			matrixStack.popPose();
		}
		
		matrixStack.popPose();
	}
	
	private void drawBox(GuiGraphics context, int x1, int y1, int x2, int y2)
	{
		ClickGui gui = NsylClient.INSTANCE.getGui();
		int bgColor =
			RenderUtils.toIntColor(gui.getBgColor(), gui.getOpacity());
		
		context.fill(x1, y1, x2, y2, bgColor);
		RenderUtils.drawBoxShadow2D(context, x1, y1, x2, y2);
	}
	
	private static final class Tab
	{
		private final String name;
		private final ArrayList<Feature> features = new ArrayList<>();
		
		private int width;
		private int height;
		private int selected;
		
		public Tab(String name)
		{
			this.name = name;
		}
		
		public void updateSize()
		{
			width = 64;
			for(Feature feature : features)
			{
				int fWidth = MC.font.width(feature.getName()) + 10;
				if(fWidth > width)
					width = fWidth;
			}
			height = features.size() * 10;
		}
		
		public void onKeyPress(int keyCode)
		{
			switch(keyCode)
			{
				case GLFW.GLFW_KEY_DOWN:
				if(selected < features.size() - 1)
					selected++;
				else
					selected = 0;
				break;
				
				case GLFW.GLFW_KEY_UP:
				if(selected > 0)
					selected--;
				else
					selected = features.size() - 1;
				break;
				
				case GLFW.GLFW_KEY_ENTER:
				onEnter();
				break;
			}
		}
		
		private void onEnter()
		{
			Feature feature = features.get(selected);
			
			TooManyHaxHack tooManyHax = NsylClient.INSTANCE.getHax().tooManyHaxHack;
			if(tooManyHax.isEnabled() && tooManyHax.isBlocked(feature))
			{
				ChatUtils
					.error(feature.getName() + " is blocked by TooManyHax.");
				return;
			}
			
			feature.doPrimaryAction();
		}
		
		public void add(Feature feature)
		{
			features.add(feature);
		}
	}
}
