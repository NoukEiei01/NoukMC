/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.clickgui.components;

import com.nsyl.client.NsylClient;
import org.lwjgl.glfw.GLFW;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import com.nsyl.client.clickgui.ClickGui;
import com.nsyl.client.clickgui.Component;
import com.nsyl.client.clickgui.screens.SelectFileScreen;
import com.nsyl.client.settings.FileSetting;
import com.nsyl.client.util.RenderUtils;

public final class FileComponent extends Component
{
	private static final ClickGui GUI = NsylClient.INSTANCE.getGui();
	private static final Font TR = MC.font;
	
	private final FileSetting setting;
	
	public FileComponent(FileSetting setting)
	{
		this.setting = setting;
		setWidth(getDefaultWidth());
		setHeight(getDefaultHeight());
	}
	
	@Override
	public void handleMouseClick(double mouseX, double mouseY, int mouseButton)
	{
		if(mouseButton != GLFW.GLFW_MOUSE_BUTTON_LEFT)
			return;
		
		if(mouseX < getX() + getWidth() - getButtonWidth() - 4)
			return;
		
		MC.setScreen(new SelectFileScreen(MC.screen, setting));
	}
	
	@Override
	public void render(GuiGraphics context, int mouseX, int mouseY,
		float partialTicks)
	{
		int x1 = getX();
		int x2 = x1 + getWidth();
		int x3 = x2 - getButtonWidth() - 4;
		int y1 = getY();
		int y2 = y1 + getHeight();
		
		boolean hovering = isHovering(mouseX, mouseY);
		boolean hText = hovering && mouseX < x3;
		boolean hBox = hovering && mouseX >= x3;
		
		// tooltip
		if(hText)
			GUI.setTooltip(setting.getWrappedDescription(200));
		else if(hBox)
			GUI.setTooltip("\u00a7e[left-click]\u00a7r to select file");
		
		// background
		context.fill(x1, y1, x3, y2, getFillColor(false));
		
		// button
		context.fill(x3, y1, x2, y2, getFillColor(hBox));
		int outlineColor = RenderUtils.toIntColor(GUI.getAcColor(), 0.5F);
		RenderUtils.drawBorder2D(context, x3, y1, x2, y2, outlineColor);
		
		// text
		int txtColor = GUI.getTxtColor();
		String labelText = setting.getName() + ":";
		String buttonText = setting.getSelectedFileName();
		context.drawString(TR, labelText, x1, y1 + 2, txtColor, false);
		context.drawString(TR, buttonText, x3 + 2, y1 + 2, txtColor, false);
	}
	
	private int getFillColor(boolean hovering)
	{
		float opacity = GUI.getOpacity() * (hovering ? 1.5F : 1);
		return RenderUtils.toIntColor(GUI.getBgColor(), opacity);
	}
	
	private int getButtonWidth()
	{
		return TR.width(setting.getSelectedFileName());
	}
	
	@Override
	public int getDefaultWidth()
	{
		String text = setting.getName() + ":";
		return TR.width(text) + getButtonWidth() + 6;
	}
	
	@Override
	public int getDefaultHeight()
	{
		return 11;
	}
}
