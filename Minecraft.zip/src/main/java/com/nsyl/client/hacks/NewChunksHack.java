/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.hacks;

import java.awt.Color;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.material.FluidState;
import com.nsyl.client.Category;
import com.nsyl.client.events.RenderListener;
import com.nsyl.client.events.UpdateListener;
import com.nsyl.client.hack.Hack;
import com.nsyl.client.hacks.newchunks.NewChunksChunkRenderer;
import com.nsyl.client.hacks.newchunks.NewChunksReasonsRenderer;
import com.nsyl.client.hacks.newchunks.NewChunksRenderer;
import com.nsyl.client.hacks.newchunks.NewChunksShowSetting;
import com.nsyl.client.hacks.newchunks.NewChunksShowSetting.Show;
import com.nsyl.client.hacks.newchunks.NewChunksStyleSetting;
import com.nsyl.client.settings.CheckboxSetting;
import com.nsyl.client.settings.ColorSetting;
import com.nsyl.client.settings.SliderSetting;
import com.nsyl.client.settings.SliderSetting.ValueDisplay;
import com.nsyl.client.util.BlockUtils;
import com.nsyl.client.util.RegionPos;
import com.nsyl.client.util.RenderUtils;
import com.nsyl.client.util.chunk.ChunkUtils;

public final class NewChunksHack extends Hack
	implements UpdateListener, RenderListener
{
	private final NewChunksStyleSetting style = new NewChunksStyleSetting();
	
	private final NewChunksShowSetting show = new NewChunksShowSetting();
	
	private final CheckboxSetting showReasons = new CheckboxSetting(
		"Show reasons",
		"Highlights the block that caused each chunk to be marked as new/old.",
		false);
	
	private final CheckboxSetting showCounter =
		new CheckboxSetting("Show counter",
			"Shows the number of new/old chunks found so far.", false);
	
	private final SliderSetting altitude =
		new SliderSetting("Altitude", 0, -64, 320, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting drawDistance =
		new SliderSetting("Draw distance", 32, 8, 64, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting opacity = new SliderSetting("Opacity", 0.75,
		0.1, 1, 0.01, ValueDisplay.PERCENTAGE);
	
	private final ColorSetting newChunksColor =
		new ColorSetting("New chunks color", Color.RED);
	
	private final ColorSetting oldChunksColor =
		new ColorSetting("Old chunks color", Color.BLUE);
	
	private final CheckboxSetting logChunks = new CheckboxSetting("Log chunks",
		"Writes to the log file when a new/old chunk is found.", false);
	
	private final Set<ChunkPos> newChunks = ConcurrentHashMap.newKeySet();
	private final Set<ChunkPos> oldChunks = ConcurrentHashMap.newKeySet();
	private final Set<ChunkPos> dontCheckAgain = ConcurrentHashMap.newKeySet();
	
	private final Set<BlockPos> newChunkReasons = ConcurrentHashMap.newKeySet();
	private final Set<BlockPos> oldChunkReasons = ConcurrentHashMap.newKeySet();
	
	private final NewChunksRenderer renderer = new NewChunksRenderer(altitude,
		opacity, newChunksColor, oldChunksColor);
	private final NewChunksReasonsRenderer reasonsRenderer =
		new NewChunksReasonsRenderer(drawDistance);
	
	// Thread pool แทน new Thread() ทุกครั้ง
	private final ExecutorService chunkCheckPool =
		Executors.newFixedThreadPool(2, r -> {
			Thread t = new Thread(r, "NewChunks-Checker");
			t.setDaemon(true);
			t.setPriority(Thread.MIN_PRIORITY);
			return t;
		});
	
	private RegionPos lastRegion;
	private DimensionType lastDimension;
	
	public NewChunksHack()
	{
		super("NewChunks");
		setCategory(Category.RENDER);
		addSetting(style);
		addSetting(show);
		addSetting(showReasons);
		addSetting(showCounter);
		addSetting(altitude);
		addSetting(drawDistance);
		addSetting(opacity);
		addSetting(newChunksColor);
		addSetting(oldChunksColor);
		addSetting(logChunks);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
		reset();
	}
	
	private void reset()
	{
		oldChunks.clear();
		newChunks.clear();
		dontCheckAgain.clear();
		oldChunkReasons.clear();
		newChunkReasons.clear();
		lastRegion = null;
		lastDimension = MC.level.dimensionType();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		renderer.closeBuffers();
	}
	
	@Override
	public String getRenderName()
	{
		if(!showCounter.isChecked())
			return getName();
		
		return String.format("%s [%d/%d]", getName(), newChunks.size(),
			oldChunks.size());
	}
	
	private boolean bufferDirty = true;
	
	@Override
	public void onUpdate()
	{
		bufferDirty = true;
	}
	
	private void rebuildBuffers()
	{
		renderer.closeBuffers();
		
		Show showSetting = show.getSelected();
		int dd = drawDistance.getValueI();
		NewChunksChunkRenderer chunkRenderer =
			style.getSelected().getChunkRenderer();
		
		if(showSetting.includesNew())
		{
			renderer.updateBuffer(0, chunkRenderer.getLayer(),
				buffer -> chunkRenderer.buildBuffer(buffer, newChunks, dd));
			
			if(showReasons.isChecked())
				renderer.updateBuffer(1, reasonsRenderer.getLayer(),
					buffer -> reasonsRenderer.buildBuffer(buffer,
						List.copyOf(newChunkReasons)));
		}
		
		if(showSetting.includesOld())
		{
			renderer.updateBuffer(2, chunkRenderer.getLayer(),
				buffer -> chunkRenderer.buildBuffer(buffer, oldChunks, dd));
			
			if(showReasons.isChecked())
				renderer.updateBuffer(3, reasonsRenderer.getLayer(),
					buffer -> reasonsRenderer.buildBuffer(buffer,
						List.copyOf(oldChunkReasons)));
		}
		
		bufferDirty = false;
	}
	
	public void afterLoadChunk(int x, int z)
	{
		if(!isEnabled())
			return;
		
		LevelChunk chunk = MC.level.getChunk(x, z);
		chunkCheckPool.submit(() -> checkLoadedChunk(chunk));
	}
	
	private void checkLoadedChunk(LevelChunk chunk)
	{
		ChunkPos chunkPos = chunk.getPos();
		if(newChunks.contains(chunkPos) || oldChunks.contains(chunkPos)
			|| dontCheckAgain.contains(chunkPos))
			return;
		
		int minX = chunkPos.getMinBlockX();
		int minY = chunk.getMinY();
		int minZ = chunkPos.getMinBlockZ();
		int maxX = chunkPos.getMaxBlockX();
		int maxY = ChunkUtils.getHighestNonEmptySectionYOffset(chunk) + 16;
		int maxZ = chunkPos.getMaxBlockZ();
		
		for(int x = minX; x <= maxX; x++)
			for(int y = minY; y <= maxY; y++)
				for(int z = minZ; z <= maxZ; z++)
				{
					BlockPos pos = new BlockPos(x, y, z);
					FluidState fluidState = chunk.getFluidState(pos);
					
					if(fluidState.isEmpty() || fluidState.isSource())
						continue;
						
					// Liquid always generates still, the flowing happens later
					// through block updates. Therefore any chunk that contains
					// flowing liquids from the start should be an old chunk.
					oldChunks.add(chunkPos);
					oldChunkReasons.add(pos);
					if(logChunks.isChecked())
						System.out.println("old chunk at " + chunkPos);
					return;
				}
				
		// If the whole loop ran through without finding anything, make sure it
		// never runs again on that chunk, as that would be a huge waste of CPU
		// time.
		dontCheckAgain.add(chunkPos);
	}
	
	public void afterUpdateBlock(BlockPos pos)
	{
		if(!isEnabled())
			return;
		
		// Liquid starts flowing -> probably a new chunk
		FluidState fluidState = BlockUtils.getState(pos).getFluidState();
		if(fluidState.isEmpty() || fluidState.isSource())
			return;
		
		ChunkPos chunkPos = new ChunkPos(pos);
		if(newChunks.contains(chunkPos) || oldChunks.contains(chunkPos))
			return;
		
		newChunks.add(chunkPos);
		newChunkReasons.add(pos);
		if(logChunks.isChecked())
			System.out.println("new chunk at " + chunkPos);
	}
	
	@Override
	public void onRender(PoseStack matrixStack, float partialTicks)
	{
		if(MC.level.dimensionType() != lastDimension)
			reset();
		
		RegionPos region = RenderUtils.getCameraRegion();
		if(!region.equals(lastRegion))
		{
			bufferDirty = true;
			lastRegion = region;
		}
		
		if(bufferDirty)
			rebuildBuffers();
		
		renderer.render(matrixStack, partialTicks);
	}
}
