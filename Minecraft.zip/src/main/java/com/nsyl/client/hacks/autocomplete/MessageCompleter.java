/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.hacks.autocomplete;

import java.io.IOException;
import java.util.List;

import com.google.gson.JsonObject;

import net.minecraft.client.GuiMessage;
import net.minecraft.client.Minecraft;
import com.nsyl.client.NsylClient;
import com.nsyl.client.util.ChatUtils;
import com.nsyl.client.util.json.JsonException;
import com.nsyl.client.util.json.WsonObject;

public abstract class MessageCompleter
{
	protected static final Minecraft MC = NsylClient.MC;
	
	protected final ModelSettings modelSettings;
	
	public MessageCompleter(ModelSettings modelSettings)
	{
		this.modelSettings = modelSettings;
	}
	
	public final String[] completeChatMessage(String draftMessage,
		int maxSuggestions)
	{
		// build prompt and parameters
		String prompt = buildPrompt(draftMessage);
		JsonObject params = buildParams(prompt, maxSuggestions);
		System.out.println(params);
		
		try
		{
			// send request
			WsonObject response = requestCompletions(params);
			System.out.println(response);
			
			// read response
			return extractCompletions(response);
			
		}catch(IOException | JsonException e)
		{
			e.printStackTrace();
			return new String[0];
		}
	}
	
	protected String buildPrompt(String draftMessage)
	{
		// tell the model that it's talking in a Minecraft chat
		String prompt = "=== Minecraft chat log ===\n";
		
		// add chat history
		List<GuiMessage.Line> chatHistory = MC.gui.getChat().trimmedMessages;
		int messages = 0;
		for(int i = chatHistory.size() - 1; i >= 0; i--)
		{
			// get message
			String message = ChatUtils.getAsString(chatHistory.get(i));
			
			// filter out NSYL messages so the model won't admit it's hacking
			if(message.startsWith(ChatUtils.NSYL_PREFIX))
				continue;
			
			// give non-player messages a sender to avoid confusing the model
			if(!message.startsWith("<"))
				if(modelSettings.filterServerMessages.isChecked())
					continue;
				else
					message = "<System> " + message;
				
			// limit context length to save tokens
			if(messages >= modelSettings.contextLength.getValueI())
				break;
			
			// add message to prompt
			prompt += message + "\n";
			messages++;
		}
		
		// if the chat history is empty, add a dummy system message
		if(chatHistory.isEmpty())
			prompt +=
				"<System> " + MC.getUser().getName() + " joined the game.\n";
		
		// add draft message
		prompt += "<" + MC.getUser().getName() + "> " + draftMessage;
		
		return prompt;
	}
	
	protected abstract JsonObject buildParams(String prompt,
		int maxSuggestions);
	
	protected abstract WsonObject requestCompletions(JsonObject parameters)
		throws IOException, JsonException;
	
	protected abstract String[] extractCompletions(WsonObject response)
		throws JsonException;
}
