/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.hacks;

import java.util.ArrayList;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import com.nsyl.client.Category;
import com.nsyl.client.SearchTags;
import com.nsyl.client.ai.PathFinder;
import com.nsyl.client.ai.PathPos;
import com.nsyl.client.ai.PathProcessor;
import com.nsyl.client.commands.PathCmd;
import com.nsyl.client.events.RenderListener;
import com.nsyl.client.events.UpdateListener;
import com.nsyl.client.hack.DontSaveState;
import com.nsyl.client.hack.Hack;
import com.nsyl.client.settings.CheckboxSetting;
import com.nsyl.client.settings.SliderSetting;
import com.nsyl.client.settings.SliderSetting.ValueDisplay;

@SearchTags({"anti afk", "AFKBot", "afk bot"})
@DontSaveState
public final class AntiAfkHack extends Hack
	implements UpdateListener, RenderListener
{
	private final CheckboxSetting useAi = new CheckboxSetting("Use AI",
		"description.nsyl.setting.antiafk.use_ai", true);
	
	private final SliderSetting aiRange = new SliderSetting("AI range",
		"description.nsyl.setting.antiafk.ai_range", 16, 1, 64, 1,
		ValueDisplay.AREA_FROM_RADIUS);
	
	private final SliderSetting nonAiRange = new SliderSetting("Non-AI range",
		"description.nsyl.setting.antiafk.non-ai_range", 1, 1, 64, 1,
		ValueDisplay.AREA_FROM_RADIUS);
	
	private final SliderSetting waitTime = new SliderSetting("Wait time",
		"description.nsyl.setting.antiafk.wait_time", 2.5, 0, 60, 0.05,
		ValueDisplay.DECIMAL.withSuffix("s"));
	
	private final SliderSetting waitTimeRand = new SliderSetting(
		"Wait time randomization",
		"description.nsyl.setting.antiafk.wait_time_randomization", 0.5, 0, 60,
		0.05, ValueDisplay.DECIMAL.withPrefix("\u00b1").withSuffix("s"));
	
	private final CheckboxSetting showWaitTime =
		new CheckboxSetting("Show wait time",
			"description.nsyl.setting.antiafk.show_wait_time", true);
	
	private int timer;
	private RandomSource random = RandomSource.createNewThreadLocalInstance();
	private BlockPos start;
	private BlockPos nextBlock;
	
	private RandomPathFinder pathFinder;
	private PathProcessor processor;
	private boolean creativeFlying;
	
	public AntiAfkHack()
	{
		super("AntiAFK");
		
		setCategory(Category.OTHER);
		addSetting(useAi);
		addSetting(aiRange);
		addSetting(nonAiRange);
		addSetting(waitTime);
		addSetting(waitTimeRand);
		addSetting(showWaitTime);
	}
	
	@Override
	public String getRenderName()
	{
		if(showWaitTime.isChecked() && timer > 0)
			return getName() + " [" + timer * 50 + "ms]";
		
		return getName();
	}
	
	@Override
	protected void onEnable()
	{
		start = BlockPos.containing(MC.player.position());
		nextBlock = null;
		pathFinder =
			new RandomPathFinder(randomize(start, aiRange.getValueI(), true));
		creativeFlying = MC.player.getAbilities().flying;
		
		CLIENT.getHax().autoFishHack.setEnabled(false);
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		PathProcessor.releaseControls();
		pathFinder = null;
		processor = null;
	}
	
	@Override
	public void onUpdate()
	{
		// check if player died
		if(MC.player.getHealth() <= 0)
		{
			setEnabled(false);
			return;
		}
		
		MC.player.getAbilities().flying = creativeFlying;
		
		if(useAi.isChecked())
		{
			// prevent drowning
			if(MC.player.isUnderWater()
				&& !CLIENT.getHax().jesusHack.isEnabled())
			{
				MC.options.keyJump.setDown(true);
				return;
			}
			
			// update timer
			if(timer > 0)
			{
				timer--;
				return;
			}
			
			// find path
			if(!pathFinder.isDone() && !pathFinder.isFailed())
			{
				PathProcessor.lockControls();
				
				pathFinder.think();
				
				if(!pathFinder.isDone() && !pathFinder.isFailed())
					return;
				
				pathFinder.formatPath();
				
				// set processor
				processor = pathFinder.getProcessor();
			}
			
			// check path
			if(processor != null
				&& !pathFinder.isPathStillValid(processor.getIndex())
				|| processor.getTicksOffPath() > 20)
			{
				pathFinder = new RandomPathFinder(pathFinder);
				return;
			}
			
			// process path
			if(!processor.isDone())
				processor.process();
			else
			{
				// reset and wait for timer
				PathProcessor.releaseControls();
				pathFinder = new RandomPathFinder(
					randomize(start, aiRange.getValueI(), true));
				setTimer();
			}
		}else
		{
			// set next block
			if(timer <= 0 || nextBlock == null)
			{
				nextBlock = randomize(start, nonAiRange.getValueI(), false);
				setTimer();
			}
			
			// face block
			CLIENT.getRotationFaker()
				.faceVectorClientIgnorePitch(Vec3.atCenterOf(nextBlock));
			
			// walk
			if(MC.player.distanceToSqr(Vec3.atCenterOf(nextBlock)) > 0.5)
				MC.options.keyUp.setDown(true);
			else
				MC.options.keyUp.setDown(false);
			
			// swim up
			MC.options.keyJump.setDown(MC.player.isInWater());
			
			// update timer
			if(timer > 0)
				timer--;
		}
	}
	
	@Override
	public void onRender(PoseStack matrixStack, float partialTicks)
	{
		if(!useAi.isChecked())
			return;
		
		PathCmd pathCmd = CLIENT.getCmds().pathCmd;
		pathFinder.renderPath(matrixStack, pathCmd.isDebugMode(),
			pathCmd.isDepthTest());
	}
	
	private void setTimer()
	{
		int baseTime = (int)(waitTime.getValue() * 20);
		double randTime = waitTimeRand.getValue() * 20;
		int randOffset = (int)(random.nextGaussian() * randTime);
		randOffset = Math.max(randOffset, -baseTime);
		timer = baseTime + randOffset;
	}
	
	private BlockPos randomize(BlockPos pos, int range, boolean includeY)
	{
		int x = random.nextInt(2 * range + 1) - range;
		int y = includeY ? random.nextInt(2 * range + 1) - range : 0;
		int z = random.nextInt(2 * range + 1) - range;
		return pos.offset(x, y, z);
	}
	
	private class RandomPathFinder extends PathFinder
	{
		public RandomPathFinder(BlockPos goal)
		{
			super(goal);
			setThinkTime(10);
			setFallingAllowed(false);
			setDivingAllowed(false);
		}
		
		public RandomPathFinder(PathFinder pathFinder)
		{
			super(pathFinder);
			setFallingAllowed(false);
			setDivingAllowed(false);
		}
		
		@Override
		public ArrayList<PathPos> formatPath()
		{
			failed = true;
			return super.formatPath();
		}
	}
}
