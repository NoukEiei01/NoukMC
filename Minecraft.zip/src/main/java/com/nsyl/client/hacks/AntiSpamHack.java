/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.hacks;

import java.util.List;

import net.minecraft.client.GuiMessage;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.components.ComponentRenderUtils;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import com.nsyl.client.Category;
import com.nsyl.client.SearchTags;
import com.nsyl.client.events.ChatInputListener;
import com.nsyl.client.hack.Hack;
import com.nsyl.client.util.ChatUtils;
import com.nsyl.client.util.MathUtils;

@SearchTags({"NoSpam", "ChatFilter", "anti spam", "no spam", "chat filter"})
public final class AntiSpamHack extends Hack implements ChatInputListener
{
	public AntiSpamHack()
	{
		super("AntiSpam");
		setCategory(Category.CHAT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(ChatInputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(ChatInputListener.class, this);
	}
	
	@Override
	public void onReceivedMessage(ChatInputEvent event)
	{
		List<GuiMessage.Line> chatLines = event.getChatLines();
		if(chatLines.isEmpty())
			return;
		
		ChatComponent chat = MC.gui.getChat();
		int maxTextLength = Mth.floor(chat.getWidth() / chat.getScale());
		List<FormattedCharSequence> newLines = ComponentRenderUtils
			.wrapComponents(event.getComponent(), maxTextLength, MC.font);
		
		int spamCounter = 1;
		int matchingLines = 0;
		
		for(int i = chatLines.size() - 1; i >= 0; i--)
		{
			String oldLine = ChatUtils.getAsString(chatLines.get(i));
			
			if(matchingLines <= newLines.size() - 1)
			{
				String newLine =
					ChatUtils.getAsString(newLines.get(matchingLines));
				
				if(matchingLines < newLines.size() - 1)
				{
					if(oldLine.equals(newLine))
						matchingLines++;
					else
						matchingLines = 0;
					
					continue;
				}
				
				if(!oldLine.startsWith(newLine))
				{
					matchingLines = 0;
					continue;
				}
				
				if(i > 0 && matchingLines == newLines.size() - 1)
				{
					String nextOldLine =
						ChatUtils.getAsString(chatLines.get(i - 1));
					
					String twoLines = oldLine + nextOldLine;
					String addedText = twoLines.substring(newLine.length());
					
					if(addedText.startsWith(" [x") && addedText.endsWith("]"))
					{
						String oldSpamCounter =
							addedText.substring(3, addedText.length() - 1);
						
						if(MathUtils.isInteger(oldSpamCounter))
						{
							spamCounter += Integer.parseInt(oldSpamCounter);
							matchingLines++;
							continue;
						}
					}
				}
				
				if(oldLine.length() == newLine.length())
					spamCounter++;
				else
				{
					String addedText = oldLine.substring(newLine.length());
					if(!addedText.startsWith(" [x") || !addedText.endsWith("]"))
					{
						matchingLines = 0;
						continue;
					}
					
					String oldSpamCounter =
						addedText.substring(3, addedText.length() - 1);
					if(!MathUtils.isInteger(oldSpamCounter))
					{
						matchingLines = 0;
						continue;
					}
					
					spamCounter += Integer.parseInt(oldSpamCounter);
				}
			}
			
			for(int i2 = i + matchingLines; i2 >= i; i2--)
				chatLines.remove(i2);
			matchingLines = 0;
		}
		
		if(spamCounter > 1)
		{
			// Someone, somewhere, is creating a MutableText object with an
			// immutable List<Text> siblings parameter, which causes the game to
			// crash when calling append(). So we always have to create a new
			// MutableText object to avoid that.
			MutableComponent oldText = (MutableComponent)event.getComponent();
			MutableComponent newText =
				MutableComponent.create(oldText.getContents());
			newText.setStyle(oldText.getStyle());
			oldText.getSiblings().forEach(newText::append);
			
			event.setComponent(newText.append(" [x" + spamCounter + "]"));
		}
	}
}
