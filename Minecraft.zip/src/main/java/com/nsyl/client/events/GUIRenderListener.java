/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.events;

import java.util.ArrayList;

import net.minecraft.client.gui.GuiGraphics;
import com.nsyl.client.event.Event;
import com.nsyl.client.event.Listener;

public interface GUIRenderListener extends Listener
{
	public void onRenderGUI(GuiGraphics context, float partialTicks);
	
	public static class GUIRenderEvent extends Event<GUIRenderListener>
	{
		private final float partialTicks;
		private final GuiGraphics context;
		
		public GUIRenderEvent(GuiGraphics context, float partialTicks)
		{
			this.context = context;
			this.partialTicks = partialTicks;
		}
		
		@Override
		public void fire(ArrayList<GUIRenderListener> listeners)
		{
			for(GUIRenderListener listener : listeners)
				listener.onRenderGUI(context, partialTicks);
		}
		
		@Override
		public Class<GUIRenderListener> getListenerType()
		{
			return GUIRenderListener.class;
		}
	}
}
