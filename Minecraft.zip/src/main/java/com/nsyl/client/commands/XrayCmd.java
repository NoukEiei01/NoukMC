/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.commands;

import com.nsyl.client.command.CmdException;
import com.nsyl.client.command.Command;

public final class XrayCmd extends Command
{
	public XrayCmd()
	{
		super("xray", "Shortcut for '.blocklist X-Ray Ores'.",
			".xray add <block>", ".xray remove <block>", ".xray list [<page>]",
			".xray reset", "Example: .xray add gravel");
	}
	
	@Override
	public void call(String[] args) throws CmdException
	{
		CLIENT.getCmdProcessor()
			.process("blocklist X-Ray Ores " + String.join(" ", args));
	}
}
