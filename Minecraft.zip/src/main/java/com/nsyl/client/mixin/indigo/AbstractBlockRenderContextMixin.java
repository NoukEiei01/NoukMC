/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.mixin.indigo;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.fabricmc.fabric.impl.client.indigo.renderer.mesh.MutableQuadViewImpl;
import net.fabricmc.fabric.impl.client.indigo.renderer.render.BlockRenderInfo;
import com.nsyl.client.NsylClient;
import com.nsyl.client.hacks.XRayHack;

@Pseudo
@Mixin(
	targets = "net.fabricmc.fabric.impl.client.indigo.renderer.render.AbstractBlockRenderContext",
	remap = false)
public abstract class AbstractBlockRenderContextMixin
{
	@Shadow
	@Final
	private BlockRenderInfo blockInfo;
	
	/**
	 * Applies X-Ray's opacity mask to the block color after all the normal
	 * coloring and shading is done, if Indigo is running.
	 */
	@Inject(at = @At("RETURN"),
		method = "shadeQuad(Lnet/fabricmc/fabric/impl/client/indigo/renderer/mesh/MutableQuadViewImpl;ZZZ)V")
	private void onShadeQuad(MutableQuadViewImpl quad, boolean ao,
		boolean emissive, boolean vanillaShade, CallbackInfo ci)
	{
		XRayHack xray = NsylClient.INSTANCE.getHax().xRayHack;
		if(!xray.isOpacityMode() || xray
			.isVisible(blockInfo.blockState.getBlock(), blockInfo.blockPos))
			return;
		
		for(int i = 0; i < 4; i++)
			quad.color(i, quad.color(i) & xray.getOpacityColorMask());
	}
}
