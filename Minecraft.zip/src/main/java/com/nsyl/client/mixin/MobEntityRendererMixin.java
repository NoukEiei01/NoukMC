/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package com.nsyl.client.mixin;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.renderer.entity.MobRenderer;
import com.nsyl.client.NsylClient;

@Mixin(MobRenderer.class)
public abstract class MobEntityRendererMixin
{
	/**
	 * Makes name-tagged mobs always show their name tags if configured in
	 * NameTags.
	 */
	@Inject(at = @At(value = "FIELD",
		target = "Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;crosshairPickEntity:Lnet/minecraft/world/entity/Entity;",
		opcode = Opcodes.GETFIELD,
		ordinal = 0),
		method = "shouldShowName(Lnet/minecraft/world/entity/Mob;D)Z",
		cancellable = true)
	private void onHasLabel(CallbackInfoReturnable<Boolean> cir)
	{
		// skip the mobEntity == dispatcher.targetedEntity check and return true
		if(NsylClient.INSTANCE.getHax().nameTagsHack.shouldForceMobNametags())
			cir.setReturnValue(true);
	}
}
